# Segunda Maratona Zabbix

Este repositório contem os arquivos da segunda maratona Zabbix.

Para fazer o deploy do ambiente siga os seguintes procedimentos

- [Deploy MySQL 8 no Centos 8](procedimentos/deploy_db.md)
- [Deploy Stack Zabbix em Docker com Centos 8](procedimentos/deploy_zabbix_front_grafana_on_docker.md)